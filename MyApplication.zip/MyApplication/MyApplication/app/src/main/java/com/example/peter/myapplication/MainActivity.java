package com.example.peter.myapplication;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ToggleButton;
import android.view.View;
import java.io.InputStream;
import android.view.Menu;
import android.view.MenuItem;
import android.util.DisplayMetrics;
import android.widget.ImageView;




import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.net.InetSocketAddress;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.DataInputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import android.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.ObjectOutputStream;

import android.os.AsyncTask;
import android.app.Activity;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.os.Handler;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.util.Log;

import static android.graphics.BitmapFactory.decodeByteArray;


public class MainActivity extends Activity {

    private boolean connectionOk = false;
    String IP_ADDR = "ip address";
    int PORT = 4014;
    private boolean locked = false;
    private Button buttonView;
    private ToggleButton buttonToggleLock;
    private volatile Socket socket = null;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        buttonView = (Button) findViewById(R.id.button2);
        buttonToggleLock = (ToggleButton) findViewById(R.id.toggleButton);
        buttonView.setOnClickListener(viewButtonRequest);
        buttonToggleLock.setOnClickListener(lockButtonRequest);
        /*
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
    }


    //On click, connect to socket and receive base64 string from socket. Decode to Bitmap image and display!
    OnClickListener viewButtonRequest = new OnClickListener() {
        @Override
        public void onClick(View arg0) {
            Log.i("MainActivity", "We Got Here!");
            InetSocketAddress addr = new InetSocketAddress("192.168.1.140", 1337);
            new ReceiveAndDisplayImage().execute(addr);
            Log.i("MainActivity", "We did not get here!");
        }
    };

    OnClickListener lockButtonRequest = new OnClickListener() {
        @Override
        public void onClick(View arg0) {
            connectionOk = false;
            if (locked) {
                Log.i("MainActivity", "We Got Here!");
                InetSocketAddress addr = new InetSocketAddress("192.168.1.140", 1337);
                new SendUnlock().execute(addr);
            } else {
                Log.i("MainActivity", "We Got Here!");
                InetSocketAddress addr = new InetSocketAddress("192.168.1.140", 1337);
                new SendLock().execute(addr);
            }
            if (!connectionOk){
                Log.i("Main Activity", "The message did not pass");
            }
            locked = !locked;
            Log.i("MainActivity", "Lock Complete");
        }
    };


    private class ReceiveAndDisplayImage extends AsyncTask<InetSocketAddress, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(InetSocketAddress... params) {
            //boolean ConnectionWorking = false;
            InetSocketAddress addr = params[0];
            //while (!ConnectionWorking) {
                try {
                    Log.i("Main Activity", "Trying to connect socket...");
                    Thread.sleep(3000);
                    socket = new Socket("192.168.1.140", 1337);
                    Log.i("Main Activity", "Socket Created!");
                    ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                    String message = "Image";
                    oos.writeObject(message);
                    oos.close();
                    socket.close();
                    Thread.sleep(1500);
                    Socket ReadSocket = new Socket("192.168.1.140", 1338);
                    ObjectInputStream ois = new ObjectInputStream(ReadSocket.getInputStream());
                    message = (String) ois.readObject();
                    Log.i("Main Activity", "String length: " + message.length());
                    Log.i("Main Activity", "String: " + message);
                    ois.close();
                    ReadSocket.close();
                    byte[] decodedString = Base64.decode(message, Base64.DEFAULT);
                    Bitmap decodedImg = decodeByteArray(decodedString, 0, decodedString.length);
                    Log.i("Main Activity", "Decoded into bitmap!");
              //      ConnectionWorking = true;
                    return decodedImg;

                } catch (UnknownHostException e) {
                    Log.i("Main Activity", "Unknown host exception");
                    return null;
                } catch (IOException e) {
                    Log.i("Main Activity", "IOException!");
                    e.printStackTrace();
                    return null;
                } catch (Exception e) {
                    Log.i("Main Activity", "Unknown exception when creating socket");
                }
            //}
            return null;
        }

        //@Override
        protected void onPostExecute(Bitmap image) {
            // update here the ui with result
            ImageView tv1 = (ImageView) findViewById(R.id.imageView);
            tv1.setImageBitmap(image);
        }
    }

        private class SendLock extends AsyncTask<InetSocketAddress, Void, Boolean> {
            @Override
            protected Boolean doInBackground(InetSocketAddress... params) {

                InetSocketAddress addr = params[0];
                try {
                    Log.i("Main Activity", "Trying to connect socket...");
                    socket = new Socket("192.168.1.140", 1337);
                    ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                    String message = "Arm";
                    oos.writeObject(message);
                    socket.close();
                    oos.close();
                    return true;
                } catch (UnknownHostException e) {
                    Log.i("Main Activity", "Unknown host exception");
                    return false;
                } catch (IOException e) {
                    Log.i("Main Activity", "IOException!");
                    e.printStackTrace();
                    return false;
                } catch (Exception e) {
                    Log.i("Main Activity", "Unknown exception when writing lock");
                    return false;
                }
            }

            //@Override
            protected void onPostExecute(Boolean complete) {
                // update here the ui with result
                if (complete){
                    connectionOk = true;
                }
            }
        }

    private class SendUnlock extends AsyncTask<InetSocketAddress, Void, Boolean> {
        @Override
        protected Boolean doInBackground(InetSocketAddress... params) {

            InetSocketAddress addr = params[0];
            try {
                Log.i("Main Activity", "Trying to connect socket...");
                socket = new Socket("192.168.1.140", 1337);
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                String message = "Disarm";
                oos.writeObject(message);
                socket.close();
                oos.close();
                return true;
            } catch (UnknownHostException e) {
                Log.i("Main Activity", "Unknown host exception");
                return false;
            } catch (IOException e) {
                Log.i("Main Activity", "IOException!");
                e.printStackTrace();
                return false;
            } catch (Exception e) {
                Log.i("Main Activity", "Unknown exception when writing lock");
                return false;
            }
        }

        //@Override
        protected void onPostExecute(Boolean complete) {
            // update here the ui with result
            if (complete){
                connectionOk = true;
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void setActivityBackgroundColor(int color) {
        View view = this.getWindow().getDecorView();
        view.setBackgroundColor(color);
    }

    //return bitmap from encoded base64 string
    public Bitmap stringToBitmap(String S) {
        byte[] imageArr = Base64.decode(S, Base64.NO_WRAP);
        Bitmap bitmap = decodeByteArray(imageArr, 0, imageArr.length);
        return bitmap;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
