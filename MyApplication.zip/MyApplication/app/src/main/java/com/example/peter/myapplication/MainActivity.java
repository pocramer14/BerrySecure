package com.example.peter.myapplication;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ToggleButton;
import android.view.View;
import java.io.InputStream;
import android.view.Menu;
import android.view.MenuItem;
import android.util.DisplayMetrics;
import android.widget.ImageView;




import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.net.InetSocketAddress;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.DataInputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import android.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import android.os.AsyncTask;
import android.app.Activity;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.os.Handler;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.util.Log;


public class MainActivity extends Activity {

    private boolean connectionOk = false;
    String IP_ADDR = "ip address";
    int PORT = 4014;
    private boolean locked = false;
    private Button buttonView;
    private ToggleButton buttonToggleLock;
    private volatile Socket socket = null;
    private ImageView imageView;
    Handler updateConversationHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        /*
        try {
            socket = new Socket("10.231.157.203", 9090);
        } catch (Exception e) {
            Log.i("MainActivity", "Error creating socket");
        }
        */

        buttonView = (Button) findViewById(R.id.button2);
        buttonToggleLock = (ToggleButton) findViewById(R.id.toggleButton);
        buttonView.setOnClickListener(viewButtonRequest);
        buttonToggleLock.setOnClickListener(lockButtonRequest);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }


    //On click, connect to socket and receive base64 string from socket. Decode to Bitmap image and display!
    OnClickListener viewButtonRequest = new OnClickListener() {
        @Override
        public void onClick(View arg0) {
            Log.i("MainActivity", "We Got Here!");
            InetSocketAddress addr = new InetSocketAddress("10.230.229.196", 9090);
            new ConnectToIpTask().execute(addr);
            Log.i("MainActivity", "We did not get here!");
        }
    };

    OnClickListener lockButtonRequest = new OnClickListener() {
        @Override
        public void onClick(View arg0) {
            if (locked) {
                try {
                    socket.getOutputStream().write(3); // Sending integer 3 = unlock
                    Log.i("MainActivity", "Application requested an unlock by writing '2' to a socket.");
                } catch (Exception e) {
                    Log.i("MainActivity", "Error sending unlock signal");
                }
            } else {
                try {
                    socket.getOutputStream().write(2); // Sending integer 2 = lock

                    Log.i("MainActivity", "Application requested a lock by writing '3' to a socket.");
                } catch (Exception e) {
                    Log.i("MainActivity", "Error sending lock signal");
                }
            }
            locked = !locked;
        }
    };


    private class ConnectToIpTask extends AsyncTask<InetSocketAddress, Void, Boolean> {

        @Override
        protected Boolean doInBackground(InetSocketAddress... params) {

            InetSocketAddress addr = params[0];
    /*
            try {
                //Log.i("Main Activity", "Trying to connect socket...");
                socket = new Socket("10.230.229.196", 9090);
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                String message = (String) ois.readObject();
                Log.i("Main Activity", "String: " + message);
                socket.close();
            } catch (UnknownHostException e) {
                Log.i("Main Activity", "Unknown host exception");
                return false;
            } catch (IOException e) {
                Log.i("Main Activity", "IOException!");
                e.printStackTrace();
                return false;
            } catch (Exception e) {
                Log.i("Main Activity", "Unknown exception when creating socket");
            }
            return true;
        }
*/
            try {
                //Log.i("Main Activity", "Trying to connect socket...");
                socket = new Socket("10.230.229.196", 9090);
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                byte[] buf = new byte[1000000000];
                ois.read(buf, 0, 1000000000);
                String message = new String(buf);
                Log.i("Main Activity", "String from bytes: " + message);
                socket.close();
            } catch (UnknownHostException e) {
                Log.i("Main Activity", "Unknown host exception");
                return false;
            } catch (IOException e) {
                Log.i("Main Activity", "IOException! Connection probably not strong enough");
                e.printStackTrace();
                return false;
            } catch (Exception e) {
                Log.i("Main Activity", "Unknown exception when creating socket");
            }
            return true;
        }
        @Override
        protected void onPostExecute(Boolean result) {
            super.onPostExecute(result);
            connectionOk = result;

            // update here the ui with result

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void setActivityBackgroundColor(int color) {
        View view = this.getWindow().getDecorView();
        view.setBackgroundColor(color);
    }

    //return bitmap from encoded base64 string
    public Bitmap stringToBitmap(String S) {
        byte[] imageArr = Base64.decode(S, Base64.NO_WRAP);
        Bitmap bitmap = BitmapFactory.decodeByteArray(imageArr, 0, imageArr.length);
        return bitmap;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
